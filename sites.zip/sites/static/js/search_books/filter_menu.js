function toggleFilterMenu() {
    const filterMenu = document.getElementById("filter-menu");
    filterMenu.style.display = filterMenu.style.display === "none" || filterMenu.style.display === "" ? "block" : "none";
}

