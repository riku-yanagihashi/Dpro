document.addEventListener("DOMContentLoaded", function() {
    const textElement = document.querySelector("#video p");
    if (textElement) {
        textElement.classList.add("show");
    }
});


document.addEventListener("DOMContentLoaded", function() {
    // transition-overlay があれば、アニメーションを再生
    const overlay = document.getElementById("transition-overlay");
    if (overlay) {
        setTimeout(() => {
            $(overlay).fadeOut(500, function() {
                $(this).remove(); // アニメーション終了後にオーバーレイを削除
            });
        }, 3000); // 遅延させてスムーズに表示
    }
});

