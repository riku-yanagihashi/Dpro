$(document).ready(function() {
    // フォーム送信時のイベント
    $("form").on("submit", function(event) {
        event.preventDefault(); // 通常の送信を防ぐ

        // アニメーションを開始
        $("body").append('<div id="transition-overlay"></div>'); // ページ遷移用のオーバーレイを追加
        $("#transition-overlay").fadeIn(500, () => {
            this.submit(); // フェードイン完了後にフォームを送信
        });
    });
});
