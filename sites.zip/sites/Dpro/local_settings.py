SECRET_KEY = 'django-insecure-c16^1r##09$+k$a8s=6rjgb$ctihgu$efpcnqz*b4w05lsm!&9'
